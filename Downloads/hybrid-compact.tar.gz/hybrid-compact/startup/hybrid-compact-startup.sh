#!/bin/bash
killall conky ; sleep 20 ; conky -c /home/dirn/.config/conky/hybrid-compact/hybrid-compact.conf &
